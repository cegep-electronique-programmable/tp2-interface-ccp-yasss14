

#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */


uint16_t Xt1 = 0;
uint16_t Xt2 = 0;
uint16_t Yt1 = 0;
uint16_t Yt2 = 0;

void CCP2_DefaultCallBack(uint16_t capturedValue);
void CCP5_DefaultCallBack(uint16_t capturedValue);

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();
    CCP2_SetCallBack(CCP2_DefaultCallBack);
    CCP5_SetCallBack(CCP5_DefaultCallBack);

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    while (1)
    {
        if(Xt1 != 0 & Xt2 != 0){
            //Curseur sur les bonnes lignes
            EUSART1_Write(0xFE);
            EUSART1_Write(0x45);
            EUSART1_Write(0x00);
            printf("Axe X: t1=%f.01ms tt=%f.01ms", Xt1, Xt1+Xt2);
            Xt1 = 0;
            Xt2 = 0;
            //il va manquer l'acceleration
            EUSART1_Write(0xFE);
            EUSART1_Write(0x45);
            EUSART1_Write(0x40);
            printf("Acce: t1=%f.01ms ", Xt1/Xt2-0.5/12.5%);
        }
        if(Yt1 != 0 & Yt2 != 0){
            //Curseur sur les bonnes lignes
            EUSART1_Write(0xFE);
            EUSART1_Write(0x45);
            EUSART1_Write(0x14);
            printf("Axe Y: t1=%f.01ms tt=%f.01ms", Yt1, Yt1+Yt2);
            Yt1 = 0;
            Yt2 = 0;
            //il va manquer l'acceleration
            EUSART1_Write(0xFE);
            EUSART1_Write(0x45);
            EUSART1_Write(0x54);
            printf("Acce: t1=%f.01ms ", Yt1/Yt2-0.5/12.5%);
        }
    }
}

void CCP2_DefaultCallBack(uint16_t capturedValue){
    
    if(CCP2CON == 0x05){    //temps haut
        CCP2CON = 0x04;
        Xt1 = capturedValue;
    }
    else{                   //temps bas
        CCP2CON = 0x05;
        Xt2 = capturedValue;
    }
    
    // Clear the CCP2 interrupt flag
    PIR3bits.CCP2IF = 0;
    
    TMR1_Reload(void);
    
}

void CCP5_DefaultCallBack(uint16_t capturedValue){
    
    if(CCP5CON == 0x05){    //temps haut
        CCP5CON = 0x04;
        Xt1 = capturedValue;
    }
    else{                   //temps bas
        CCP5CON = 0x05;
        Xt2 = capturedValue;
    }
    
    // Clear the CCP2 interrupt flag
    PIR4bits.CCP5IF = 0;
    
    TMR3_Reload(void);
}

/**
 End of File
*/