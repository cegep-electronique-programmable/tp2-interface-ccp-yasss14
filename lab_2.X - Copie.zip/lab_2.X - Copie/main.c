
#include "mcc_generated_files/mcc.h"
typedef enum 
{
    neutre,
    L,
    U,
    zero
}etat_1;

etat_1 etat;
int i = 0;
char verif;
uint16_t dutyValue;
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
   
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    if (EUSART1_is_rx_ready)
        { 
            printf("%c option 1 : barrage(L) \n\r" );
            printf("%c option 2 : debarrage(U) \n\r" );
        } 
        
    while (1)
    { 
        switch (etat) 
        {
        case neutre :
            if (EUSART1_is_rx_ready)
                {
                    verif = EUSART1_Read();
                
                    if (verif == 'l') // VERIFIE LE CARACTERE
                    { 
                        printf("%c barrage reussi \n\r", verif );
                        PWM2_LoadDutyValue(71); 
                        break;
                    }  
                    
                    else if (verif == 'u')
                    {   
                        printf("%c debarrage reussi \n\r",verif );   
                        PWM2_LoadDutyValue(21); 
                        break;
                    }
                    else  
                    {    
                        printf("%c etat 0 \n\r",verif );
                        PWM2_LoadDutyValue(46);                          
                    }
                    break; 
                }                       
        } 
    }
}
